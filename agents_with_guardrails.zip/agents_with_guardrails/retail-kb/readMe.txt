You need to download the `demo_csbot_db` file from  https://github.com/aws-samples/agentsforbedrock-retailagent/blob/main/data/demo_csbot_db and put it in this folder.

You can read more about the `demo_csbot_db` here, https://github.com/aws-samples/agentsforbedrock-retailagent/
